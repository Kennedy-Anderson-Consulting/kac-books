# SPDX-FileCopyrightText: 2023-present Kennedy Anderson Consulting LLC <kennedy@kennedyandersonconsulting.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.1"
