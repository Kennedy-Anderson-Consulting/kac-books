CREATE TYPE account_category AS ENUM (
	'ASSET',
	'LIABILITY',
	'EQUITY',
	'INCOME',
	'EXPENSE'
);
