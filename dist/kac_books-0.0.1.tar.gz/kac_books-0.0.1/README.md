# kac-books
A basic bookkeeping application using python, urwid, and postgresql.
